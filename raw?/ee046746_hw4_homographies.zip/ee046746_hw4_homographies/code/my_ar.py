import numpy as np
import matplotlib.pyplot as plt
import cv2
import scipy
from matplotlib import pyplot as plt
import my_homography as mh
#Add imports if needed:
    """
    Your code here
    """
#end imports

#Add functions here:
"""
   Your code here
"""
#Functions end

# HW functions:
def create_ref(im_path):
    """
       Your code here
    """
    return ref_image

if __name__ == '__main__':
    print('my_ar')